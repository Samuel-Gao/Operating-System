#include <stdio.h>
#include <assert.h>
#include <unistd.h>
#include <getopt.h>
#include <stdlib.h>
#include "pagetable.h"


extern int memsize;

extern int debug;

extern struct frame *coremap;

int *stack; //0 is top of stack
int stack_count; 

/* Page to evict is chosen using the accurate LRU algorithm.
 * Returns the page frame number (which is also the index in the coremap)
 * for the page that is to be evicted.
 */

int lru_evict() {
	return stack[stack_count - 1];
}

/* Helper function to shift elements of the stack from
 * 0 to position down by 1 and add frame to top of stack
 */
void add_to_stack(int position, int frame){
	int c;
	for (c = position; c > 0; c -- ){
		stack[c] = stack[c-1];
	}
	stack[0] = frame;
}

/* This function is called on each access to a page to update any information
 * needed by the lru algorithm.
 * Input: The page table entry for the page that is being accessed.
 */
void lru_ref(pgtbl_entry_t *p) {

	int frame = p->frame >> PAGE_SHIFT;
	
	//If stack is not full, add to top of stack
	if (stack_count < memsize){
		add_to_stack(0, frame);
		stack_count++;
	
	//if stack full check if page exist on stack
	}else if (stack_count >= memsize){

		//page at top of the stack. 
		if (stack[0] == frame){
			add_to_stack(stack_count-1, frame);
			return; 
		
		//page somewhere on stack, move it to top
		}else{
			int c;
			for (c=1; c < memsize; c++){
				if (stack[c] == frame){
					add_to_stack(c, frame);
					return;
				}
			}


		}

		//page not on stack, replace bottom of stack
		add_to_stack(stack_count-1, frame);
	}

	return;
}


/* Initialize any data structures needed for this 
 * replacement algorithm 
 */
void lru_init() {
	stack = malloc(memsize * sizeof(int));
	stack_count = 0;

}
